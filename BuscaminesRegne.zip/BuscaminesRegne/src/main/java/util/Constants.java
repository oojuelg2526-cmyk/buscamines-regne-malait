package util;

import java.awt.*;

public class Constants {

    // ── Dimensions finestra ──────────────────────────────────────
    public static final int FINESTRA_AMPLADA = 430;
    public static final int FINESTRA_ALCADA  = 760;
    public static final int BARRA_ESTAT_ALCADA = 74;

    // ── Mides casella ────────────────────────────────────────────
    public static final int MIDA_CASELLA_MIN = 8;
    public static final int MIDA_CASELLA_MAX = 52;
    public static final int MIDA_CASELLA_TARGET_FACIL = 38;
    public static final int MIDA_CASELLA_TARGET_INTERMEDIA = 23;
    public static final int MIDA_CASELLA_TARGET_DIFICIL = 23;

    // ── Tipus personatge ─────────────────────────────────────────
    public static final String TIPUS_MAG      = "Mag";
    public static final String TIPUS_GUERRER  = "Guerrer";
    public static final String TIPUS_SACERDOT = "Sacerdot";

    // ── Dificultats ──────────────────────────────────────────────
    public static final String DIFICULTAT_FACIL      = "Facil";
    public static final String DIFICULTAT_INTERMEDIA = "Intermedia";
    public static final String DIFICULTAT_DIFICIL    = "Dificil";

    // ── Colors medievals ─────────────────────────────────────────
    public static final Color COLOR_FONS_FOSC        = new Color(25, 16, 8);
    public static final Color COLOR_PEDRA            = new Color(60, 45, 30);
    public static final Color COLOR_PEDRA_CLARA      = new Color(160, 140, 110);
    public static final Color COLOR_DAURAT           = new Color(180, 140, 40);
    public static final Color COLOR_DAURAT_CLAR      = new Color(220, 190, 100);
    public static final Color COLOR_VERMELL_MEDIEVAL = new Color(139, 0, 0);
    public static final Color COLOR_VERD_MEDIEVAL    = new Color(34, 85, 34);
    public static final Color COLOR_CASELLA_REVELADA = new Color(55, 40, 25);
    public static final Color COLOR_CASELLA_BUIDA    = new Color(35, 25, 15);
    public static final Color COLOR_CURSOR_TECLAT    = new Color(255, 215, 0, 60);
    public static final Color COLOR_ZONA_NOVA        = new Color(80, 100, 200, 50);
    public static final Color COLOR_VORA             = new Color(100, 75, 45);
    public static final Color COLOR_VORA_CLARA       = new Color(130, 100, 65);
    public static final Color COLOR_VORA_FOSCA       = new Color(20, 12, 5);

    // ── Colors números buscamines ────────────────────────────────
    public static final Color[] COLORS_NUMEROS = {
        Color.BLACK,
        new Color(40, 125, 255),
        new Color(35, 170, 55),
        new Color(230, 55, 45),
        new Color(45, 70, 210),
        new Color(150, 35, 20),
        new Color(25, 165, 175),
        new Color(20, 20, 20),
        new Color(110, 110, 110)
    };

    // ── Fonts ────────────────────────────────────────────────────
    public static final Font FONT_TITOL  = new Font("Serif", Font.BOLD, 28);
    public static final Font FONT_BOTO   = new Font("Serif", Font.BOLD, 13);
    public static final Font FONT_NORMAL = new Font("Serif", Font.PLAIN, 14);
}
