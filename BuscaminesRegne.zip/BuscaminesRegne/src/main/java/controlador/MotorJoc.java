package controlador;

import model.*;
import util.Constants;

import javax.swing.Timer;
import java.util.*;

/**
 * MotorJoc inclou:
 * - Primer clic GARANTIT: zona segura adaptada per dificultat
 *   · Fàcil      → radi 2 (mínim 5-7 caselles obertes)
 *   · Intermèdia → radi 2
 *   · Difícil    → radi 1 (mínim 3 caselles obertes)
 * - Flood-fill iteratiu (sense StackOverflow)
 */
public class MotorJoc {

    private Casella[][] tauler;
    private int files;
    private int columnes;
    private int nombreTrampes;
    private int puntsBase;
    private String dificultat;

    private Personatge personatge;
    private int idUsuari;

    private int tempsSecs = 0;
    private int ampliacions = 0;
    private int multiplicador = 1;
    private boolean jocActiu = false;
    private boolean primeraVegada = true;
    private int casellesSeguresRestants;

    private JocListener listener;
    private Timer cronometre;
    private final GestorBD gestorBD;

    public MotorJoc() {
        this.gestorBD = GestorBD.getInstance();
    }

    // ════════════════════════════════════════════════════════════
    // INICIAR PARTIDA
    // ════════════════════════════════════════════════════════════

    public void iniciar_partida(String nom, String dificultat, String tipusPersonatge, int idUsuari) {
        this.idUsuari = idUsuari;
        this.dificultat = dificultat;
        this.personatge = crearPersonatge(nom, tipusPersonatge);
        this.tempsSecs = 0;
        this.ampliacions = 0;
        this.multiplicador = 1;
        this.primeraVegada = true;

        configurarDificultat(dificultat);
        generar_tauler(dificultat);
        iniciar_cronometre();
    }

    private Personatge crearPersonatge(String nom, String tipus) {
        return switch (tipus) {
            case Constants.TIPUS_MAG      -> new Mag(nom);
            case Constants.TIPUS_GUERRER  -> new Guerrer(nom);
            case Constants.TIPUS_SACERDOT -> new Sacerdot(nom);
            default                       -> new Mag(nom);
        };
    }

    private void configurarDificultat(String dif) {
        switch (dif) {
            case Constants.DIFICULTAT_FACIL      -> { files=9;  columnes=9;  nombreTrampes=10; puntsBase=100; }
            case Constants.DIFICULTAT_INTERMEDIA -> { files=16; columnes=16; nombreTrampes=40; puntsBase=200; }
            case Constants.DIFICULTAT_DIFICIL    -> { files=24; columnes=16; nombreTrampes=75; puntsBase=350; }
            default                              -> { files=9;  columnes=9;  nombreTrampes=10; puntsBase=100; }
        }
    }

    public void generar_tauler(String dif) {
        tauler = new Casella[files][columnes];
        for (int i = 0; i < files; i++)
            for (int j = 0; j < columnes; j++)
                tauler[i][j] = new Casella();

        casellesSeguresRestants = (files * columnes) - nombreTrampes;
        if (listener != null) listener.onTaulerCreat();
    }

    // ────────────────────────────────────────────────────────────
    // ZONA SEGURA GARANTIDA AL PRIMER CLIC
    // ────────────────────────────────────────────────────────────

    /**
     * Retorna el radi de zona segura segons dificultat:
     *   Fàcil/Intermèdia → radi 2 (garanteix ≥5 caselles lliures al voltant)
     *   Difícil          → radi 1 (mínim 3 caselles obertes)
     */
    private int getRadiZonaSegura() {
        return dificultat.equals(Constants.DIFICULTAT_DIFICIL) ? 1 : 2;
    }

    private void colocarTrampes(int filaSafe, int colSafe) {
        int radi = getRadiZonaSegura();
        Random rnd = new Random();
        int col = 0;
        int maxInts = nombreTrampes * 50;
        int intents = 0;
        while (col < nombreTrampes && intents < maxInts) {
            intents++;
            int f = rnd.nextInt(files);
            int c = rnd.nextInt(columnes);
            // Excloure zona segura (quadrat de radi 'radi' al voltant del primer clic)
            boolean esSafe = Math.abs(f - filaSafe) <= radi && Math.abs(c - colSafe) <= radi;
            if (!tauler[f][c].isEsTrampa() && !esSafe) {
                tauler[f][c].setEsTrampa(true);
                col++;
            }
        }
        calcularAdjacents();
    }

    private void calcularAdjacents() {
        for (int i = 0; i < files; i++) {
            for (int j = 0; j < columnes; j++) {
                if (!tauler[i][j].isEsTrampa()) {
                    int compt = 0;
                    for (int di = -1; di <= 1; di++)
                        for (int dj = -1; dj <= 1; dj++) {
                            int ni = i+di, nj = j+dj;
                            if (ni>=0 && ni<files && nj>=0 && nj<columnes && tauler[ni][nj].isEsTrampa())
                                compt++;
                        }
                    tauler[i][j].setNombreTrampaAdjacents(compt);
                }
            }
        }
    }

    // ────────────────────────────────────────────────────────────
    // CRONÒMETRE
    // ────────────────────────────────────────────────────────────

    public void iniciar_cronometre() {
        if (cronometre != null) cronometre.stop();
        jocActiu = true;
        cronometre = new Timer(1000, e -> {
            if (jocActiu) {
                tempsSecs++;
                if (listener != null) listener.onActualitzarTimer(tempsSecs);
            }
        });
        cronometre.start();
    }

    public void aturar_cronometre() {
        if (cronometre != null) cronometre.stop();
        jocActiu = false;
    }

    // ════════════════════════════════════════════════════════════
    // ACCIONS JOC
    // ════════════════════════════════════════════════════════════

    public void marcar_bandera(int fila, int col) {
        if (!jocActiu || !dinsTauler(fila, col)) return;
        Casella c = tauler[fila][col];
        if (c.isRevelada()) return;
        c.setMarcadaBandera(!c.isMarcadaBandera());
        if (listener != null) {
            listener.onBanderaMarcada(fila, col);
            listener.onActualitzarUI();
        }
    }

    public void revelar_casella(int fila, int col) {
        if (!jocActiu || !dinsTauler(fila, col)) return;
        Casella c = tauler[fila][col];
        if (c.isRevelada()) {
            revelar_adjacents_si_banderes(fila, col);
            return;
        }
        if (c.isMarcadaBandera()) return;

        if (primeraVegada) {
            primeraVegada = false;
            colocarTrampes(fila, col);
        }

        c.setRevelada(true);
        comprovar_trampa(fila, col);
    }

    private void comprovar_trampa(int fila, int col) {
        Casella c = tauler[fila][col];
        if (c.isEsTrampa()) {
            perdre_vida_per_trampa();
        } else {
            casellesSeguresRestants--;
            if (c.getNombreTrampaAdjacents() == 0) {
                revelar_adjacents(fila, col);
            }
            if (listener != null) listener.onActualitzarUI();
            comprovar_victoria();
        }
    }

    private void perdre_vida_per_trampa() {
        int videsRestants = Math.max(0, personatge.getVides() - 1);
        personatge.setVides(videsRestants);
        if (videsRestants <= 0) {
            derrota();
        } else if (listener != null) {
            listener.onActualitzarUI();
        }
    }

    // Flood-fill iteratiu (evita StackOverflow en taulers grans)
    private void revelar_adjacents(int filaInici, int colInici) {
        Queue<int[]> cua = new LinkedList<>();
        cua.add(new int[]{filaInici, colInici});

        while (!cua.isEmpty()) {
            int[] pos = cua.poll();
            int f = pos[0], c = pos[1];
            for (int di = -1; di <= 1; di++) {
                for (int dj = -1; dj <= 1; dj++) {
                    if (di == 0 && dj == 0) continue;
                    int nf = f+di, nc = c+dj;
                    if (nf<0 || nf>=files || nc<0 || nc>=columnes) continue;
                    Casella vei = tauler[nf][nc];
                    if (!vei.isRevelada() && !vei.isMarcadaBandera() && !vei.isEsTrampa()) {
                        vei.setRevelada(true);
                        casellesSeguresRestants--;
                        if (casellesSeguresRestants < 0) casellesSeguresRestants = 0;
                        if (vei.getNombreTrampaAdjacents() == 0) {
                            cua.add(new int[]{nf, nc});
                        }
                    }
                }
            }
        }
    }

    private void comprovar_victoria() {
        if (casellesSeguresRestants <= 0) {
            aturar_cronometre();
            int puntuacio = calcular_puntuacio(tempsSecs, dificultat) * multiplicador;
            if (listener != null) listener.onVictoria(puntuacio);
        }
    }

    public void revelar_adjacents_si_banderes(int fila, int col) {
        if (!jocActiu || !dinsTauler(fila, col)) return;
        Casella origen = tauler[fila][col];
        if (!origen.isRevelada() || origen.getNombreTrampaAdjacents() <= 0) return;

        int banderesAdjacents = 0;
        for (int di = -1; di <= 1; di++) {
            for (int dj = -1; dj <= 1; dj++) {
                if (di == 0 && dj == 0) continue;
                int nf = fila + di;
                int nc = col + dj;
                if (dinsTauler(nf, nc) && tauler[nf][nc].isMarcadaBandera()) {
                    banderesAdjacents++;
                }
            }
        }
        if (banderesAdjacents != origen.getNombreTrampaAdjacents()) return;

        for (int di = -1; di <= 1 && jocActiu; di++) {
            for (int dj = -1; dj <= 1 && jocActiu; dj++) {
                if (di == 0 && dj == 0) continue;
                int nf = fila + di;
                int nc = col + dj;
                if (dinsTauler(nf, nc)) {
                    Casella vei = tauler[nf][nc];
                    if (!vei.isRevelada() && !vei.isMarcadaBandera()) {
                        revelar_casella(nf, nc);
                    }
                }
            }
        }
    }

    public int calcular_puntuacio(int temps, String dif) {
        double bonusRapidesa = personatge.getBonusRapidesa();
        int bonus = (int)(Math.max(0, 300 - temps) / 10.0 * bonusRapidesa * personatge.getVelocitat());
        return puntsBase + bonus;
    }

    public void derrota() {
        aturar_cronometre();
        revelarTotesLesTrampes();
        gestorBD.guardar_partida(idUsuari, gestorBD.getIdNivell(dificultat),
                personatge.getTipusPersonatge(), 0, tempsSecs, ampliacions, "derrota");
        if (listener != null) listener.onDerrota(tempsSecs);
    }

    private void revelarTotesLesTrampes() {
        for (int i=0; i<files; i++)
            for (int j=0; j<columnes; j++)
                if (tauler[i][j].isEsTrampa()) tauler[i][j].setRevelada(true);
    }

    public void confirmar_guardar(int puntuacio) {
        gestorBD.guardar_partida(idUsuari, gestorBD.getIdNivell(dificultat),
                personatge.getTipusPersonatge(), puntuacio, tempsSecs, ampliacions, "victoria");
        gestorBD.actualitzar_punts_totals(idUsuari, puntuacio);
    }

    public void confirmar_ampliar() { ampliar_tauler(); }

    public void ampliar_tauler() {
        ampliacions++;
        multiplicador *= 2;
        int oldFiles = files, oldColumnes = columnes;
        int novaFiles = files + 4, novaColumnes = columnes + 5;

        Casella[][] nouTauler = new Casella[novaFiles][novaColumnes];
        for (int i=0; i<novaFiles; i++) {
            for (int j=0; j<novaColumnes; j++) {
                if (i < files && j < columnes) {
                    nouTauler[i][j] = tauler[i][j];
                    nouTauler[i][j].setZonaNova(false);
                } else {
                    nouTauler[i][j] = new Casella();
                    nouTauler[i][j].setZonaNova(true);
                }
            }
        }

        files = novaFiles; columnes = novaColumnes; tauler = nouTauler;
        int trampesAfegides = afegir_trampes_noves(oldFiles, oldColumnes);
        nombreTrampes += trampesAfegides;
        calcularAdjacents();

        int novesSegures = 0;
        for (int i=0; i<files; i++)
            for (int j=0; j<columnes; j++)
                if (!tauler[i][j].isRevelada() && !tauler[i][j].isEsTrampa()) novesSegures++;
        casellesSeguresRestants = novesSegures;

        primeraVegada = false;
        jocActiu = true;
        if (cronometre != null) cronometre.start();
        if (listener != null) listener.onTaulerAmpliat(multiplicador);
    }

    private int afegir_trampes_noves(int oldFiles, int oldColumnes) {
        int novesTotals = (files * columnes) - (oldFiles * oldColumnes);
        int novesTotalsAmbTrampes = Math.max(3, novesTotals / 4);
        Random rnd = new Random();
        int colocades = 0;
        int maxInts = novesTotalsAmbTrampes * 20;
        for (int i=0; i<maxInts && colocades<novesTotalsAmbTrampes; i++) {
            int f = rnd.nextInt(files), c = rnd.nextInt(columnes);
            boolean esNova = (f >= oldFiles) || (c >= oldColumnes);
            if (esNova && !tauler[f][c].isEsTrampa() && !tauler[f][c].isRevelada()) {
                tauler[f][c].setEsTrampa(true); colocades++;
            }
        }
        return colocades;
    }

    private boolean dinsTauler(int fila, int col) {
        return fila >= 0 && fila < files && col >= 0 && col < columnes;
    }

    // ════════════════════════════════════════════════════════════
    // GETTERS
    // ════════════════════════════════════════════════════════════

    public Casella[][] getTauler()    { return tauler; }
    public Casella getCasella(int f, int c) { return tauler[f][c]; }
    public int getFiles()             { return files; }
    public int getColumnes()          { return columnes; }
    public int getNombreTrampes()     { return nombreTrampes; }
    public String getDificultat()     { return dificultat; }
    public Personatge getPersonatge() { return personatge; }
    public int getTempsSecs()         { return tempsSecs; }
    public int getAmpliacions()       { return ampliacions; }
    public int getMultiplicador()     { return multiplicador; }
    public boolean isJocActiu()       { return jocActiu; }
    public void setListener(JocListener l) { this.listener = l; }
    public int getCasellesSeguresRestants() { return Math.max(0, casellesSeguresRestants); }
    public int getPuntuacioActual() {
        return calcular_puntuacio(tempsSecs, dificultat) * multiplicador;
    }

    public int getBanderesRestants() {
        int marcades = 0;
        if (tauler == null) return nombreTrampes;
        for (int i=0; i<files; i++)
            for (int j=0; j<columnes; j++)
                if (tauler[i][j].isMarcadaBandera()) marcades++;
        return nombreTrampes - marcades;
    }
}
