package controlador;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * GestorBD – Singleton per a la connexió MySQL.
 * Sempre usa PreparedStatement i try-with-resources.
 * Si no hi ha connexió, bdDisponible = false i el joc funciona en mode offline.
 */
public class GestorBD {

    private static GestorBD instancia;
    private String url;
    private String user;
    private String password;
    private boolean bdDisponible = false;

    private GestorBD() {
        carregarConfig();
        provarConnexio();
    }

    public static GestorBD getInstance() {
        if (instancia == null) {
            instancia = new GestorBD();
        }
        return instancia;
    }

    private void carregarConfig() {
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            if (is == null) {
                url = "jdbc:mysql://localhost:3306/buscamines_regne";
                user = "root";
                password = "";
                return;
            }
            Properties props = new Properties();
            props.load(is);
            url      = props.getProperty("db.url",      "jdbc:mysql://localhost:3306/buscamines_regne");
            user     = props.getProperty("db.user",     "root");
            password = props.getProperty("db.password", "");
        } catch (IOException e) {
            url = "jdbc:mysql://localhost:3306/buscamines_regne";
            user = "root";
            password = "";
        }
    }

    private void provarConnexio() {
        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            bdDisponible = conn != null && !conn.isClosed();
        } catch (SQLException e) {
            bdDisponible = false;
        }
    }

    private Connection getConnexio() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    public boolean isBdDisponible() { return bdDisponible; }

    // ── cercar_usuari ─────────────────────────────────────────────
    public int[] cercar_usuari(String nom) {
        if (!bdDisponible) return null;
        String sql = "SELECT id_usuari, punts_totals FROM usuaris WHERE nom_jugador = ?";
        try (Connection conn = getConnexio();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nom);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new int[]{rs.getInt("id_usuari"), rs.getInt("punts_totals")};
                }
            }
        } catch (SQLException e) {
            System.err.println("cercar_usuari: " + e.getMessage());
        }
        return null;
    }

    // ── crear_usuari ──────────────────────────────────────────────
    public int crear_usuari(String nom, String tipusPersonatge) {
        if (!bdDisponible) return -1;
        String sql = "INSERT INTO usuaris (nom_jugador, tipus_personatge, punts_totals) VALUES (?, ?, 0)";
        try (Connection conn = getConnexio();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, nom);
            ps.setString(2, tipusPersonatge);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("crear_usuari: " + e.getMessage());
        }
        return -1;
    }

    // ── guardar_partida ───────────────────────────────────────────
    public void guardar_partida(int idUsuari, int idNivell, String tipusPersonatge,
                                int puntuacio, int tempsSecs, int ampliacions, String resultat) {
        if (!bdDisponible) return;
        String sql = "INSERT INTO partides (id_usuari, id_nivell, tipus_personatge, " +
                     "puntuacio_obtinguda, temps_segons, ampliacions, resultat) VALUES (?,?,?,?,?,?,?)";
        try (Connection conn = getConnexio();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idUsuari);
            ps.setInt(2, idNivell);
            ps.setString(3, tipusPersonatge);
            ps.setInt(4, puntuacio);
            ps.setInt(5, tempsSecs);
            ps.setInt(6, ampliacions);
            ps.setString(7, resultat);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("guardar_partida: " + e.getMessage());
        }
    }

    // ── actualitzar_punts_totals ──────────────────────────────────
    public void actualitzar_punts_totals(int idUsuari, int puntsNous) {
        if (!bdDisponible) return;
        String sql = "UPDATE usuaris SET punts_totals = punts_totals + ? WHERE id_usuari = ?";
        try (Connection conn = getConnexio();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, puntsNous);
            ps.setInt(2, idUsuari);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("actualitzar_punts_totals: " + e.getMessage());
        }
    }

    // ── Top10 Millor Partida ──────────────────────────────────────
    public List<Object[]> getTop10MillorPartida() {
        List<Object[]> llista = new ArrayList<>();
        if (!bdDisponible) return llista;
        String sql = "SELECT u.nom_jugador, MAX(p.puntuacio_obtinguda) AS millor_puntuacio, " +
                     "p.tipus_personatge, MAX(p.data_partida) AS ultima_data " +
                     "FROM partides p JOIN usuaris u ON p.id_usuari = u.id_usuari " +
                     "WHERE p.resultat = 'victoria' " +
                     "GROUP BY u.nom_jugador, p.tipus_personatge " +
                     "ORDER BY millor_puntuacio DESC LIMIT 10";
        try (Connection conn = getConnexio();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                llista.add(new Object[]{
                    rs.getString("nom_jugador"),
                    rs.getInt("millor_puntuacio"),
                    rs.getString("tipus_personatge"),
                    rs.getTimestamp("ultima_data")
                });
            }
        } catch (SQLException e) {
            System.err.println("getTop10MillorPartida: " + e.getMessage());
        }
        return llista;
    }

    // ── Top10 Puntuació Total ─────────────────────────────────────
    public List<Object[]> getTop10PuntuacioTotal() {
        List<Object[]> llista = new ArrayList<>();
        if (!bdDisponible) return llista;
        String sql = "SELECT nom_jugador, punts_totals FROM usuaris ORDER BY punts_totals DESC LIMIT 10";
        try (Connection conn = getConnexio();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                llista.add(new Object[]{rs.getString("nom_jugador"), rs.getInt("punts_totals")});
            }
        } catch (SQLException e) {
            System.err.println("getTop10PuntuacioTotal: " + e.getMessage());
        }
        return llista;
    }

    // ── Obtenir id_nivell per dificultat ──────────────────────────
    public int getIdNivell(String dificultat) {
        switch (dificultat) {
            case "Facil":      return 1;
            case "Intermedia": return 2;
            case "Dificil":    return 3;
            default:           return 1;
        }
    }
}
