package controlador;

public interface JocListener {
    void onTaulerCreat();
    void onActualitzarUI();
    void onActualitzarTimer(int tempsSecs);
    void onBanderaMarcada(int fila, int col);
    void onDerrota(int tempsSecs);
    void onVictoria(int puntuacio);
    void onTaulerAmpliat(int multiplicador);
}
