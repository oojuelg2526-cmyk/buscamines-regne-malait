package vista;

import controlador.GestorBD;
import util.Constants;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class RanquingPanel extends JDialog {

    public RanquingPanel(Frame parent) {
        super(parent, "Ranquing del Regne", true);
        setSize(400, 620);
        setLocationRelativeTo(parent);
        setResizable(false);
        construirUI();
    }

    private void construirUI() {
        JPanel fons = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, new Color(12, 8, 4),
                        0, getHeight(), new Color(6, 3, 1)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        fons.setBorder(BorderFactory.createLineBorder(Constants.COLOR_DAURAT, 3));

        JLabel lblTitol = new JLabel("\uD83C\uDFC6  RANQUING DEL REGNE  \uD83C\uDFC6", SwingConstants.CENTER);
        lblTitol.setFont(new Font("Serif", Font.BOLD, 20));
        lblTitol.setForeground(Constants.COLOR_DAURAT_CLAR);
        lblTitol.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, Constants.COLOR_DAURAT),
                new EmptyBorder(18, 20, 16, 20)));
        fons.add(lblTitol, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Serif", Font.BOLD, 15));
        tabs.addTab("\uD83C\uDFC6  MILLOR PARTIDA", crearTaulaMillorPartida());
        tabs.addTab("\uD83D\uDCCA  PUNTUACIO TOTAL", crearTaulaPuntuacioTotal());
        fons.add(tabs, BorderLayout.CENTER);

        JButton btnTancar = crearBoto("Tancar");
        btnTancar.addActionListener(e -> dispose());
        JPanel peu = new JPanel();
        peu.setOpaque(false);
        peu.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(2, 0, 0, 0, Constants.COLOR_DAURAT),
                new EmptyBorder(12, 0, 14, 0)));
        peu.add(btnTancar);
        fons.add(peu, BorderLayout.SOUTH);
        setContentPane(fons);
    }

    private JScrollPane crearTaulaMillorPartida() {
        String[] capcaleres = {"Posicio", "Jugador", "Millor puntuacio", "Personatge", "Data"};
        List<Object[]> dades = GestorBD.getInstance().getTop10MillorPartida();
        Object[][] data = new Object[dades.size()][5];
        for (int i = 0; i < dades.size(); i++) {
            Object[] fila = dades.get(i);
            data[i][0] = medalla(i + 1);
            data[i][1] = fila[0];
            data[i][2] = fila[1] + " pts";
            data[i][3] = fila[2];
            data[i][4] = fila[3];
        }
        return crearScrollTaula(data, capcaleres);
    }

    private JScrollPane crearTaulaPuntuacioTotal() {
        String[] capcaleres = {"Posicio", "Jugador", "Punts totals"};
        List<Object[]> dades = GestorBD.getInstance().getTop10PuntuacioTotal();
        Object[][] data = new Object[dades.size()][3];
        for (int i = 0; i < dades.size(); i++) {
            Object[] fila = dades.get(i);
            data[i][0] = medalla(i + 1);
            data[i][1] = fila[0];
            data[i][2] = fila[1] + " pts";
        }
        return crearScrollTaula(data, capcaleres);
    }

    private String medalla(int pos) {
        return switch (pos) {
            case 1 -> "\uD83E\uDD47";
            case 2 -> "\uD83E\uDD48";
            case 3 -> "\uD83E\uDD49";
            default -> pos + ".";
        };
    }

    private JScrollPane crearScrollTaula(Object[][] data, String[] capcaleres) {
        DefaultTableModel model = new DefaultTableModel(data, capcaleres) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        JTable taula = new JTable(model);
        taula.setFont(new Font("Serif", Font.PLAIN, 14));
        taula.setForeground(Constants.COLOR_DAURAT_CLAR);
        taula.setBackground(new Color(22, 14, 7));
        taula.setGridColor(new Color(80, 58, 28));
        taula.setRowHeight(32);
        taula.setSelectionBackground(new Color(80, 58, 20));
        taula.setSelectionForeground(Constants.COLOR_DAURAT_CLAR);
        taula.setShowHorizontalLines(true);
        taula.setShowVerticalLines(false);
        taula.setIntercellSpacing(new Dimension(0, 1));
        taula.setDefaultRenderer(Object.class, new AlternatingRenderer());

        JTableHeader header = taula.getTableHeader();
        header.setFont(new Font("Serif", Font.BOLD, 14));
        header.setBackground(new Color(40, 26, 10));
        header.setForeground(Constants.COLOR_DAURAT);
        header.setPreferredSize(new Dimension(0, 36));

        DefaultTableCellRenderer centrat = new AlternatingRenderer();
        centrat.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < taula.getColumnCount(); i++) {
            taula.getColumnModel().getColumn(i).setCellRenderer(centrat);
        }

        JScrollPane scroll = new JScrollPane(taula);
        scroll.setBackground(new Color(12, 7, 3));
        scroll.getViewport().setBackground(new Color(22, 14, 7));
        scroll.setBorder(new EmptyBorder(10, 14, 10, 14));
        return scroll;
    }

    private JButton crearBoto(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(new Color(50, 34, 12));
        btn.setForeground(Constants.COLOR_DAURAT);
        btn.setFont(new Font("Serif", Font.BOLD, 15));
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Constants.COLOR_DAURAT, 2),
                new EmptyBorder(10, 28, 10, 28)));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        return btn;
    }

    private static class AlternatingRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setHorizontalAlignment(SwingConstants.CENTER);
            if (!isSelected) {
                c.setBackground(row % 2 == 0 ? new Color(22, 14, 7) : new Color(32, 20, 10));
                c.setForeground(Constants.COLOR_DAURAT_CLAR);
            }
            return c;
        }
    }
}
