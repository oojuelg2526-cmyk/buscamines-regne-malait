package vista;

import model.Personatge;
import util.Constants;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class PantallaVictoria extends JDialog {

    private boolean veurePanell = false;

    public PantallaVictoria(JFrame parent, int puntuacio, int tempsSecs,
                            int ampliacions, int multiplicador, Personatge personatge) {
        super(parent, "Victòria!", true);
        setSize(390, 420);
        setLocationRelativeTo(parent);
        setUndecorated(false);
        setResizable(false);

        JPanel fons = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setPaint(new GradientPaint(0, 0, new Color(10, 25, 10), 0, getHeight(), new Color(5, 15, 5)));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        fons.setBorder(BorderFactory.createLineBorder(Constants.COLOR_DAURAT, 3));

        // Títol
        JLabel lblTitol = new JLabel("\uD83C\uDFC6  VICTÒRIA!", SwingConstants.CENTER);
        lblTitol.setFont(new Font("Serif", Font.BOLD, 30));
        lblTitol.setForeground(Constants.COLOR_DAURAT_CLAR);
        lblTitol.setBorder(new EmptyBorder(28, 20, 10, 20));
        fons.add(lblTitol, BorderLayout.NORTH);

        // Info
        JPanel info = new JPanel(new GridLayout(5, 1, 0, 8));
        info.setOpaque(false);
        info.setBorder(new EmptyBorder(10, 34, 10, 34));
        info.add(crearLinia("Aventurer", personatge.getNom() + " (" + personatge.getTipusPersonatge() + ")"));
        info.add(crearLinia("\u2605 Puntuacio", String.valueOf(puntuacio) + " pts"));
        int min = tempsSecs/60, sec = tempsSecs%60;
        info.add(crearLinia("\u23F1 Temps", String.format("%02d:%02d", min, sec)));
        info.add(crearLinia("\uD83D\uDDFA Ampliacions", String.valueOf(ampliacions)));
        info.add(crearLinia("\u00D7 Multiplicador", "\u00D7" + multiplicador));
        fons.add(info, BorderLayout.CENTER);

        // Botons
        JPanel botons = new JPanel(new GridLayout(1, 2, 16, 0));
        botons.setOpaque(false);
        botons.setBorder(new EmptyBorder(10, 28, 26, 28));

        JButton btnRanq   = crearBoto("Veure Ranquing", new Color(60, 45, 15), Constants.COLOR_DAURAT);
        JButton btnTancar = crearBoto("Menu Principal", new Color(20, 50, 20), new Color(150, 255, 150));

        btnRanq.addActionListener(e -> { veurePanell = true; dispose(); });
        btnTancar.addActionListener(e -> dispose());

        botons.add(btnRanq);
        botons.add(btnTancar);
        fons.add(botons, BorderLayout.SOUTH);
        setContentPane(fons);
    }

    private JPanel crearLinia(String clave, String valor) {
        JPanel p = new JPanel(new BorderLayout(12, 0));
        p.setOpaque(false);
        JLabel k = new JLabel(clave);
        k.setFont(new Font("Serif", Font.BOLD, 14));
        k.setForeground(Constants.COLOR_PEDRA_CLARA);
        JLabel v = new JLabel(valor, SwingConstants.RIGHT);
        v.setFont(new Font("Serif", Font.BOLD, 15));
        v.setForeground(Constants.COLOR_DAURAT_CLAR);
        p.add(k, BorderLayout.WEST);
        p.add(v, BorderLayout.EAST);
        return p;
    }

    private JButton crearBoto(String text, Color bg, Color fg) {
        JButton btn = new JButton(text);
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFont(new Font("Serif", Font.BOLD, 15));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Constants.COLOR_DAURAT, 2),
            new EmptyBorder(12, 16, 12, 16)));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        return btn;
    }

    public boolean esVeurePanell() { return veurePanell; }
}
