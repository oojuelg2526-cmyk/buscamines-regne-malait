package vista;

import util.Constants;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

public class DialogAmplacioMaleida extends JDialog {

    private boolean assegurar = true;

    public DialogAmplacioMaleida(JFrame parent, int puntuacio, int multiplicadorActual) {
        super(parent, "L'Ampliaci\u00f3 Male\u00efda", true);
        setSize(390, 620);
        setLocationRelativeTo(parent);
        setResizable(false);

        JPanel fons = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth();
                int h = getHeight();
                g2.setPaint(new GradientPaint(0, 0, new Color(25, 16, 10), 0, h, new Color(7, 5, 4)));
                g2.fillRect(0, 0, w, h);
                g2.setColor(new Color(255, 255, 255, 28));
                for (int r = 35; r < 300; r += 11) {
                    for (int a = 190; a < 350; a += 7) {
                        int x = w / 2 + (int) (Math.cos(Math.toRadians(a)) * r);
                        int y = 0 + (int) (Math.sin(Math.toRadians(a)) * r);
                        g2.fillOval(x, y, 2, 2);
                    }
                }
                g2.dispose();
            }
        };
        fons.setBorder(BorderFactory.createLineBorder(new Color(157, 116, 42), 3));

        JPanel cap = new JPanel(new GridLayout(3, 1, 0, 4));
        cap.setOpaque(false);
        cap.setBorder(new EmptyBorder(20, 18, 6, 18));
        JLabel lblRisk = new JLabel("RISK IT", SwingConstants.CENTER);
        lblRisk.setFont(new Font("Serif", Font.BOLD, 44));
        lblRisk.setForeground(new Color(245, 238, 228));
        JLabel lblSub = new JLabel("Dobla la puntuacio o perd-ho tot.", SwingConstants.CENTER);
        lblSub.setFont(new Font("Serif", Font.PLAIN, 18));
        lblSub.setForeground(new Color(238, 230, 218));
        JLabel lblNom = new JLabel("L'AMPLIACI\u00d3 MALE\u00cfDA", SwingConstants.CENTER);
        lblNom.setFont(new Font("Serif", Font.BOLD, 16));
        lblNom.setForeground(new Color(215, 171, 69));
        cap.add(lblRisk);
        cap.add(lblSub);
        cap.add(lblNom);
        fons.add(cap, BorderLayout.NORTH);

        JPanel pergami = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth();
                int h = getHeight();
                g2.setColor(new Color(55, 34, 20, 190));
                g2.fillRoundRect(6, 10, w - 12, h - 16, 24, 24);
                g2.setPaint(new GradientPaint(0, 0, new Color(245, 224, 176), 0, h, new Color(190, 145, 82)));
                g2.fill(new RoundRectangle2D.Double(18, 0, w - 36, h - 8, 18, 18));
                g2.setColor(new Color(128, 91, 34));
                g2.setStroke(new BasicStroke(3f));
                g2.draw(new RoundRectangle2D.Double(24, 8, w - 48, h - 24, 16, 16));
                g2.dispose();
            }
        };
        pergami.setOpaque(false);
        pergami.setBorder(new EmptyBorder(28, 28, 28, 28));

        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1.0;

        g.gridy = 0;
        JLabel lblHasGuanyat = new JLabel("HAS GUANYAT", SwingConstants.CENTER);
        lblHasGuanyat.setFont(new Font("Serif", Font.BOLD, 31));
        lblHasGuanyat.setForeground(new Color(145, 20, 20));
        pergami.add(lblHasGuanyat, g);

        g.gridy = 1;
        g.insets = new Insets(14, 0, 4, 0);
        JLabel lblEscut = new JLabel("\uD83D\uDEE1", SwingConstants.CENTER);
        lblEscut.setFont(new Font("Serif", Font.PLAIN, 42));
        pergami.add(lblEscut, g);

        g.gridy = 2;
        JLabel lblPunts = new JLabel(puntuacio + " punts assegurables", SwingConstants.CENTER);
        lblPunts.setFont(new Font("Serif", Font.BOLD, 15));
        lblPunts.setForeground(new Color(72, 48, 22));
        pergami.add(lblPunts, g);

        g.gridy = 3;
        g.insets = new Insets(22, 0, 14, 0);
        JButton btnAssegurar = new BotoDecisio("ASSEGURAR PUNTS", new Color(0, 138, 54), new Color(210, 255, 220));
        btnAssegurar.addActionListener(e -> { assegurar = true; dispose(); });
        pergami.add(btnAssegurar, g);

        g.gridy = 4;
        g.insets = new Insets(0, 0, 8, 0);
        JButton btnAmpliar = new BotoDecisio("AMPLIAR TAULER  x" + (multiplicadorActual * 2), new Color(150, 18, 12), Color.WHITE);
        btnAmpliar.addActionListener(e -> { assegurar = false; dispose(); });
        pergami.add(btnAmpliar, g);

        g.gridy = 5;
        JLabel avis = new JLabel("Si falles, la partida queda a 0 punts.", SwingConstants.CENTER);
        avis.setFont(new Font("Serif", Font.BOLD, 14));
        avis.setForeground(new Color(110, 35, 20));
        pergami.add(avis, g);

        JPanel centre = new JPanel(new GridBagLayout());
        centre.setOpaque(false);
        centre.add(pergami, new GridBagConstraints());
        fons.add(centre, BorderLayout.CENTER);

        JPanel peu = new JPanel(new GridLayout(1, 3, 18, 0));
        peu.setOpaque(false);
        peu.setBorder(new EmptyBorder(4, 20, 18, 20));
        peu.add(crearPill("Score", "x2"));
        peu.add(crearPill("Score", "x4"));
        peu.add(crearPill("Score", "x8"));
        fons.add(peu, BorderLayout.SOUTH);

        setContentPane(fons);
    }

    private JLabel crearPill(String a, String b) {
        JLabel lbl = new JLabel("<html><center>" + a + "<br>" + b + "</center></html>", SwingConstants.CENTER);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 15));
        lbl.setForeground(new Color(210, 159, 54));
        lbl.setOpaque(true);
        lbl.setBackground(new Color(48, 27, 11));
        lbl.setBorder(new EmptyBorder(8, 16, 8, 16));
        return lbl;
    }

    public boolean esAssegurar() {
        return assegurar;
    }

    private static class BotoDecisio extends JButton {
        private final Color base;
        private final Color text;

        BotoDecisio(String label, Color base, Color text) {
            super(label);
            this.base = base;
            this.text = text;
            setForeground(text);
            setFont(new Font("Serif", Font.BOLD, 18));
            setBorder(new EmptyBorder(15, 10, 15, 10));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { repaint(); }
                @Override public void mouseExited(MouseEvent e) { repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color c = getModel().isRollover() ? base.brighter() : base;
            g2.setPaint(new GradientPaint(0, 0, c.brighter(), getWidth(), getHeight(), c.darker().darker()));
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
            g2.setColor(new Color(240, 235, 220));
            g2.setStroke(new BasicStroke(2.5f));
            g2.drawRoundRect(4, 4, getWidth() - 9, getHeight() - 9, 10, 10);
            g2.setColor(new Color(255, 255, 255, 60));
            g2.drawLine(12, 10, getWidth() - 12, 10);
            g2.dispose();
            setForeground(text);
            super.paintComponent(g);
        }
    }
}
