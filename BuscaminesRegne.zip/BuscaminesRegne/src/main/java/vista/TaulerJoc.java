package vista;

import controlador.JocListener;
import controlador.MotorJoc;
import model.Casella;
import util.Constants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TaulerJoc extends JPanel implements JocListener, MouseListener, MouseMotionListener, KeyListener, FocusListener {

    private final MotorJoc motorJoc;
    private final BarraEstat barraEstat;
    private final JFrame frameJoc;
    private final Runnable tornarAlMenu;

    private boolean modeBandera = false;
    private int midaCasella = 35;
    private int offsetX = 10;
    private int offsetY = 10;
    private int hoverFila = -1;
    private int hoverCol = -1;
    private int cursorFila = 0;
    private int cursorCol = 0;
    private boolean cursorActiu = false;
    private boolean ressaltarZonaNova = false;

    public TaulerJoc(MotorJoc motorJoc, BarraEstat barraEstat,
                     JFrame frameJoc, Runnable tornarAlMenu) {
        this.motorJoc = motorJoc;
        this.barraEstat = barraEstat;
        this.frameJoc = frameJoc;
        this.tornarAlMenu = tornarAlMenu;
        motorJoc.setListener(this);
        cursorFila = Math.max(0, motorJoc.getFiles() / 2);
        cursorCol = Math.max(0, motorJoc.getColumnes() / 2);
        setBackground(new Color(8, 5, 2));
        setPreferredSize(new Dimension(700, 600));
        setFocusable(true);
        addMouseListener(this);
        addMouseMotionListener(this);
        addKeyListener(this);
        addFocusListener(this);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (motorJoc == null || motorJoc.getTauler() == null) return;

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int files = motorJoc.getFiles();
        int columnes = motorJoc.getColumnes();
        int dispW = getWidth() - 24;
        int dispH = getHeight() - 24;
        midaCasella = Math.min(dispW / columnes, dispH / files);
        midaCasella = Math.max(midaCasella, Constants.MIDA_CASELLA_MIN);
        midaCasella = Math.min(midaCasella, Constants.MIDA_CASELLA_MAX);

        int boardW = midaCasella * columnes;
        int boardH = midaCasella * files;
        offsetX = Math.max(12, (getWidth() - boardW) / 2);
        offsetY = Math.max(12, (getHeight() - boardH) / 2);

        pintarMarc(g2, boardW, boardH);
        for (int i = 0; i < files; i++) {
            for (int j = 0; j < columnes; j++) {
                pintarCasella(g2, i, j);
            }
        }
        pintarCursorTeclat(g2);
        g2.dispose();
    }

    private void pintarMarc(Graphics2D g2, int boardW, int boardH) {
        g2.setColor(new Color(0, 0, 0, 150));
        g2.fillRoundRect(offsetX - 9, offsetY - 9, boardW + 18, boardH + 18, 10, 10);
        g2.setColor(Constants.COLOR_DAURAT.darker());
        g2.setStroke(new BasicStroke(4f));
        g2.drawRoundRect(offsetX - 7, offsetY - 7, boardW + 14, boardH + 14, 8, 8);
        g2.setColor(Constants.COLOR_VORA_CLARA);
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawRoundRect(offsetX - 3, offsetY - 3, boardW + 6, boardH + 6, 4, 4);
    }

    private void pintarCasella(Graphics2D g2, int fila, int col) {
        Casella c = motorJoc.getCasella(fila, col);
        int x = offsetX + col * midaCasella;
        int y = offsetY + fila * midaCasella;
        int w = midaCasella - 1;
        int h = midaCasella - 1;

        if (c.isRevelada()) {
            if (c.isEsTrampa()) {
                g2.setPaint(new GradientPaint(x, y, new Color(145, 15, 15), x + w, y + h, new Color(12, 2, 2)));
                g2.fillRect(x, y, w, h);
                g2.setColor(new Color(255, 70, 60, 120));
                g2.drawRect(x, y, w, h);
                g2.setColor(new Color(245, 235, 220));
                dibuixarText(g2, "\u2620", x, y, w, h, fontSize(midaCasella) + 3);
            } else if (c.getNombreTrampaAdjacents() == 0) {
                g2.setPaint(new GradientPaint(x, y, new Color(142, 112, 78), x + w, y + h, new Color(104, 75, 48)));
                g2.fillRect(x, y, w, h);
                g2.setColor(new Color(76, 54, 34));
                g2.drawRect(x, y, w, h);
            } else {
                g2.setPaint(new GradientPaint(x, y, new Color(198, 162, 105), x + w, y + h, new Color(156, 114, 66)));
                g2.fillRect(x, y, w, h);
                g2.setColor(new Color(104, 72, 38));
                g2.drawRect(x, y, w, h);
                int num = c.getNombreTrampaAdjacents();
                g2.setColor(new Color(255, 238, 185, 120));
                dibuixarText(g2, String.valueOf(num), x - 1, y - 1, w, h, fontSize(midaCasella));
                g2.setColor(new Color(0, 0, 0, 165));
                dibuixarText(g2, String.valueOf(num), x + 1, y + 1, w, h, fontSize(midaCasella));
                g2.setColor(Constants.COLORS_NUMEROS[num]);
                dibuixarText(g2, String.valueOf(num), x, y, w, h, fontSize(midaCasella));
            }
        } else {
            pintarNoRevelada(g2, x, y, w, h, fila == hoverFila && col == hoverCol);
            if (c.isMarcadaBandera()) {
                g2.setColor(new Color(255, 220, 80));
                dibuixarText(g2, "\u2691", x, y, w, h, fontSize(midaCasella) + 1);
            }
        }

        if (ressaltarZonaNova && c.isZonaNova() && !c.isRevelada()) {
            g2.setColor(Constants.COLOR_ZONA_NOVA);
            g2.fillRect(x + 2, y + 2, Math.max(1, w - 4), Math.max(1, h - 4));
            g2.setColor(new Color(120, 150, 255, 170));
            g2.drawRect(x + 2, y + 2, Math.max(1, w - 4), Math.max(1, h - 4));
        }
    }

    private void pintarNoRevelada(Graphics2D g2, int x, int y, int w, int h, boolean hover) {
        Color c1 = hover ? new Color(76, 58, 42) : new Color(43, 34, 29);
        Color c2 = hover ? new Color(38, 27, 20) : new Color(20, 17, 15);
        g2.setPaint(new GradientPaint(x + w / 2f, y + h / 2f, c1, x + w, y + h, c2));
        g2.fillRect(x, y, w, h);
        g2.setColor(hover ? new Color(205, 166, 76) : new Color(92, 75, 58));
        g2.drawLine(x, y, x + w - 1, y);
        g2.drawLine(x, y, x, y + h - 1);
        g2.setColor(new Color(3, 3, 3));
        g2.drawLine(x + w - 1, y, x + w - 1, y + h - 1);
        g2.drawLine(x, y + h - 1, x + w - 1, y + h - 1);
    }

    private void pintarCursorTeclat(Graphics2D g2) {
        if (!cursorActiu || !motorJoc.isJocActiu()) return;
        int x = offsetX + cursorCol * midaCasella;
        int y = offsetY + cursorFila * midaCasella;
        g2.setColor(new Color(255, 215, 0, hasFocus() ? 60 : 28));
        g2.fillRect(x, y, midaCasella - 1, midaCasella - 1);
        g2.setColor(new Color(255, 215, 0, hasFocus() ? 225 : 120));
        g2.setStroke(new BasicStroke(2f));
        g2.drawRect(x + 1, y + 1, midaCasella - 3, midaCasella - 3);
    }

    private void dibuixarText(Graphics2D g2, String text, int x, int y, int w, int h, int fs) {
        g2.setFont(new Font("Serif", Font.BOLD, fs));
        FontMetrics fm = g2.getFontMetrics();
        int tx = x + (w - fm.stringWidth(text)) / 2;
        int ty = y + (h + fm.getAscent() - fm.getDescent()) / 2;
        g2.drawString(text, tx, ty);
    }

    private int fontSize(int cellSize) {
        return Math.max(8, cellSize - 3);
    }

    private int[] pixelACasella(int px, int py) {
        if (midaCasella <= 0) return null;
        int col = (px - offsetX) / midaCasella;
        int fila = (py - offsetY) / midaCasella;
        if (fila >= 0 && fila < motorJoc.getFiles() && col >= 0 && col < motorJoc.getColumnes()) {
            return new int[]{fila, col};
        }
        return null;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    private void processarMouse(MouseEvent e) {
        requestFocusInWindow();
        if (!motorJoc.isJocActiu()) return;
        int[] pos = pixelACasella(e.getX(), e.getY());
        if (pos == null) return;
        cursorActiu = false;
        if (SwingUtilities.isRightMouseButton(e) || modeBandera) {
            motorJoc.marcar_bandera(pos[0], pos[1]);
        } else {
            motorJoc.revelar_casella(pos[0], pos[1]);
        }
    }

    @Override public void mousePressed(MouseEvent e) { processarMouse(e); }
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {
        hoverFila = -1;
        hoverCol = -1;
        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        int[] pos = pixelACasella(e.getX(), e.getY());
        int nf = pos == null ? -1 : pos[0];
        int nc = pos == null ? -1 : pos[1];
        if (nf != hoverFila || nc != hoverCol) {
            hoverFila = nf;
            hoverCol = nc;
            repaint();
        }
    }

    @Override public void mouseDragged(MouseEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        if (!motorJoc.isJocActiu()) return;
        int salt = e.isShiftDown() ? 5 : 1;
        boolean mogut = true;
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP -> cursorFila = Math.max(0, cursorFila - salt);
            case KeyEvent.VK_DOWN -> cursorFila = Math.min(motorJoc.getFiles() - 1, cursorFila + salt);
            case KeyEvent.VK_LEFT -> cursorCol = Math.max(0, cursorCol - salt);
            case KeyEvent.VK_RIGHT -> cursorCol = Math.min(motorJoc.getColumnes() - 1, cursorCol + salt);
            case KeyEvent.VK_ENTER, KeyEvent.VK_SPACE -> {
                cursorActiu = true;
                if (e.isShiftDown()) motorJoc.marcar_bandera(cursorFila, cursorCol);
                else motorJoc.revelar_casella(cursorFila, cursorCol);
                repaint();
                return;
            }
            case KeyEvent.VK_F -> {
                cursorActiu = true;
                motorJoc.marcar_bandera(cursorFila, cursorCol);
                repaint();
                return;
            }
            case KeyEvent.VK_B -> {
                setModeBandera(!modeBandera);
                repaint();
                return;
            }
            case KeyEvent.VK_ESCAPE -> {
                confirmarSortida();
                return;
            }
            default -> mogut = false;
        }
        if (mogut) {
            cursorActiu = true;
            mantenirCursorVisible();
            repaint();
        }
    }

    private void mantenirCursorVisible() {
        Rectangle r = new Rectangle(
                offsetX + cursorCol * midaCasella,
                offsetY + cursorFila * midaCasella,
                midaCasella,
                midaCasella);
        scrollRectToVisible(r);
    }

    private void confirmarSortida() {
        int opcio = JOptionPane.showConfirmDialog(frameJoc,
                "Vols tornar al menu principal? La partida actual es perdra.",
                "Sortir de la partida",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
        if (opcio == JOptionPane.YES_OPTION) {
            motorJoc.derrota();
        }
    }

    @Override public void keyTyped(KeyEvent e) {}
    @Override public void keyReleased(KeyEvent e) {}
    @Override public void focusGained(FocusEvent e) { repaint(); }
    @Override public void focusLost(FocusEvent e) { repaint(); }

    @Override
    public void onTaulerCreat() {
        SwingUtilities.invokeLater(this::actualitzar_ui_tauler);
    }

    @Override
    public void onActualitzarUI() {
        SwingUtilities.invokeLater(() -> {
            barraEstat.actualitzarBanderes(motorJoc.getBanderesRestants());
            barraEstat.actualitzarRestants(motorJoc.getCasellesSeguresRestants());
            barraEstat.actualitzarVides(motorJoc.getPersonatge().getVides());
            barraEstat.actualitzarPuntuacio(motorJoc.getPuntuacioActual());
            barraEstat.actualitzarMultiplicador(motorJoc.getMultiplicador());
            repaint();
        });
    }

    @Override
    public void onActualitzarTimer(int t) {
        SwingUtilities.invokeLater(() -> {
            barraEstat.actualitzarCronometre(t);
            barraEstat.actualitzarPuntuacio(motorJoc.getPuntuacioActual());
        });
    }

    @Override
    public void onBanderaMarcada(int fila, int col) {
        SwingUtilities.invokeLater(() -> {
            barraEstat.actualitzarBanderes(motorJoc.getBanderesRestants());
            barraEstat.actualitzarRestants(motorJoc.getCasellesSeguresRestants());
            repaint();
        });
    }

    @Override
    public void onDerrota(int tempsSecs) {
        SwingUtilities.invokeLater(() -> {
            repaint();
            javax.swing.Timer delay = new javax.swing.Timer(700, ev -> {
                new PantallaDerrota(frameJoc, tempsSecs, motorJoc.getPersonatge()).setVisible(true);
                tornarAlMenu.run();
            });
            delay.setRepeats(false);
            delay.start();
        });
    }

    @Override
    public void onVictoria(int puntuacio) {
        SwingUtilities.invokeLater(() -> {
            repaint();
            mostrarDecisioVictoria(puntuacio);
        });
    }

    @Override
    public void onTaulerAmpliat(int multiplicador) {
        SwingUtilities.invokeLater(() -> {
            ressaltarZonaNova = true;
            actualitzar_ui_tauler();
            barraEstat.actualitzarBanderes(motorJoc.getBanderesRestants());
            barraEstat.actualitzarRestants(motorJoc.getCasellesSeguresRestants());
            barraEstat.actualitzarMultiplicador(multiplicador);
            javax.swing.Timer t = new javax.swing.Timer(3000, e -> {
                ressaltarZonaNova = false;
                repaint();
            });
            t.setRepeats(false);
            t.start();
            requestFocusInWindow();
        });
    }

    private void mostrarDecisioVictoria(int puntuacio) {
        DialogAmplacioMaleida dlg = new DialogAmplacioMaleida(frameJoc, puntuacio, motorJoc.getMultiplicador());
        dlg.setVisible(true);
        if (dlg.esAssegurar()) {
            motorJoc.confirmar_guardar(puntuacio);
            PantallaVictoria pv = new PantallaVictoria(frameJoc, puntuacio,
                    motorJoc.getTempsSecs(), motorJoc.getAmpliacions(), motorJoc.getMultiplicador(), motorJoc.getPersonatge());
            pv.setVisible(true);
            if (pv.esVeurePanell()) new RanquingPanel(frameJoc).setVisible(true);
            tornarAlMenu.run();
        } else {
            motorJoc.confirmar_ampliar();
        }
    }

    public void actualitzar_ui_tauler() {
        if (motorJoc == null) return;
        int cellTarget = switch (motorJoc.getDificultat()) {
            case Constants.DIFICULTAT_FACIL -> Constants.MIDA_CASELLA_TARGET_FACIL;
            case Constants.DIFICULTAT_INTERMEDIA -> Constants.MIDA_CASELLA_TARGET_INTERMEDIA;
            default -> Constants.MIDA_CASELLA_TARGET_DIFICIL;
        };
        int ampladaDisponible = Constants.FINESTRA_AMPLADA - 44;
        int cellFit = Math.max(Constants.MIDA_CASELLA_MIN, ampladaDisponible / motorJoc.getColumnes());
        int cell = Math.min(cellTarget, cellFit);
        setPreferredSize(new Dimension(motorJoc.getColumnes() * cell + 24,
                motorJoc.getFiles() * cell + 24));
        revalidate();
        repaint();
    }

    public void setModeBandera(boolean modeBandera) {
        this.modeBandera = modeBandera;
        barraEstat.actualitzarModeBandera(modeBandera);
    }

    public boolean isModeBandera() {
        return modeBandera;
    }
}
