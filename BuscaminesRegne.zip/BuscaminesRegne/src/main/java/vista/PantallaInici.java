package vista;

import controlador.GestorBD;
import controlador.MotorJoc;
import model.Personatge;
import util.Constants;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class PantallaInici extends JFrame {

    private final MotorJoc motorJoc = new MotorJoc();
    private String tipusPersonatgeSeleccionat = Constants.TIPUS_MAG;
    private String dificultatSeleccionada = Constants.DIFICULTAT_FACIL;
    private JTextField txtNom;
    private JButton[] btnsPersonatge = new JButton[3];
    private JButton[] btnsDificultat = new JButton[3];

    public PantallaInici() {
        super("Buscamines del Regne Male\u00eft");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(Constants.FINESTRA_AMPLADA, Constants.FINESTRA_ALCADA);
        setResizable(false);
        setLocationRelativeTo(null);
        construirUI();
        SwingUtilities.invokeLater(() -> txtNom.requestFocusInWindow());
    }

    private void construirUI() {
        JPanel fons = new FonsIniciPanel();
        fons.setLayout(new BorderLayout(0, 10));
        fons.setBorder(new EmptyBorder(18, 18, 18, 18));

        fons.add(crearBarraSuperior(), BorderLayout.NORTH);
        fons.add(crearContingutPrincipal(), BorderLayout.CENTER);
        setContentPane(fons);
    }

    private JPanel crearBarraSuperior() {
        JPanel barra = new JPanel(new BorderLayout(8, 0));
        barra.setOpaque(false);

        JLabel marca = new JLabel("<html><b>BUSCAMINES</b><br><span style='font-size:10px'>DEL REGNE MALE\u00cfT</span></html>");
        marca.setFont(new Font("Serif", Font.BOLD, 18));
        marca.setForeground(new Color(214, 176, 84));

        JButton btnRanquing = new JButton("\uD83C\uDFC6");
        btnRanquing.setToolTipText("Classificacio");
        btnRanquing.setFont(new Font("SansSerif", Font.BOLD, 20));
        btnRanquing.setForeground(new Color(222, 178, 72));
        btnRanquing.setBackground(new Color(42, 25, 10));
        btnRanquing.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(138, 101, 38), 1),
                new EmptyBorder(7, 11, 7, 11)));
        btnRanquing.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRanquing.setFocusPainted(false);
        btnRanquing.setOpaque(true);
        btnRanquing.addActionListener(e -> new RanquingPanel(this).setVisible(true));

        barra.add(marca, BorderLayout.WEST);
        barra.add(btnRanquing, BorderLayout.EAST);
        return barra;
    }

    private JPanel crearContingutPrincipal() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);

        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1.0;

        g.gridy = 0;
        g.insets = new Insets(0, 0, 4, 0);
        JLabel titol = new JLabel("CHOOSE", SwingConstants.CENTER);
        titol.setFont(new Font("Serif", Font.BOLD, 52));
        titol.setForeground(new Color(246, 239, 228));
        p.add(titol, g);

        g.gridy = 1;
        g.insets = new Insets(0, 0, 18, 0);
        JLabel subtitol = new JLabel("Facil. Intermedia. Dificil.", SwingConstants.CENTER);
        subtitol.setFont(new Font("Serif", Font.PLAIN, 21));
        subtitol.setForeground(new Color(235, 228, 214));
        p.add(subtitol, g);

        g.gridy = 2;
        g.insets = new Insets(0, 8, 10, 8);
        txtNom = new JTextField();
        txtNom.setHorizontalAlignment(SwingConstants.CENTER);
        txtNom.setToolTipText("Introdueix el teu nom...");
        txtNom.setBackground(new Color(39, 11, 15));
        txtNom.setForeground(new Color(245, 226, 160));
        txtNom.setCaretColor(new Color(245, 226, 160));
        txtNom.setFont(new Font("Serif", Font.BOLD, 17));
        txtNom.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 135, 48), 2),
                new EmptyBorder(11, 12, 11, 12)));
        txtNom.addActionListener(e -> iniciarPartida());
        p.add(txtNom, g);

        g.gridy = 3;
        g.insets = new Insets(0, 0, 16, 0);
        p.add(crearPersonatges(), g);

        g.gridy = 4;
        g.insets = new Insets(0, 0, 7, 0);
        JLabel etiquetaDif = new JLabel("TRIA LA DIFICULTAT", SwingConstants.CENTER);
        etiquetaDif.setFont(new Font("Serif", Font.BOLD, 14));
        etiquetaDif.setForeground(new Color(206, 164, 69));
        p.add(etiquetaDif, g);

        g.gridy = 5;
        g.insets = new Insets(0, 22, 12, 22);
        p.add(crearDificultats(), g);

        g.gridy = 6;
        g.insets = new Insets(4, 38, 0, 38);
        JButton btnJugar = new BotoOrnamental("INICIAR AVENTURA", new Color(32, 83, 38), new Color(236, 218, 148), 17);
        btnJugar.addActionListener(e -> iniciarPartida());
        p.add(btnJugar, g);

        g.gridy = 7;
        g.insets = new Insets(12, 26, 0, 26);
        JLabel ajuda = new JLabel("<html><center>El nom identifica el jugador al ranquing.<br>La partida pot continuar amb l'Ampliacio Maleida.</center></html>", SwingConstants.CENTER);
        ajuda.setFont(new Font("Serif", Font.PLAIN, 12));
        ajuda.setForeground(new Color(154, 132, 96));
        p.add(ajuda, g);

        return p;
    }

    private JPanel crearPersonatges() {
        JPanel p = new JPanel(new GridLayout(1, 3, 8, 0));
        p.setOpaque(false);
        btnsPersonatge[0] = crearCardPersonatge("\uD83E\uDDD9", "MAG", "Vides 3", Constants.TIPUS_MAG);
        btnsPersonatge[1] = crearCardPersonatge("\u2694", "GUERRER", "Vides 5", Constants.TIPUS_GUERRER);
        btnsPersonatge[2] = crearCardPersonatge("\u271D", "SACERDOT", "Vides 4", Constants.TIPUS_SACERDOT);
        for (JButton b : btnsPersonatge) p.add(b);
        actualitzarSeleccioPersonatge();
        return p;
    }

    private JPanel crearDificultats() {
        JPanel p = new JPanel(new GridLayout(3, 1, 0, 10));
        p.setOpaque(false);
        btnsDificultat[0] = crearBotoDificultat("FACIL", "9x9  ·  100 pts", Constants.DIFICULTAT_FACIL);
        btnsDificultat[1] = crearBotoDificultat("INTERMEDIA", "16x16  ·  200 pts", Constants.DIFICULTAT_INTERMEDIA);
        btnsDificultat[2] = crearBotoDificultat("DIFICIL", "24x16  ·  350 pts", Constants.DIFICULTAT_DIFICIL);
        for (JButton b : btnsDificultat) p.add(b);
        actualitzarSeleccioDificultat();
        return p;
    }

    private JButton crearCardPersonatge(String icon, String nom, String desc, String tipus) {
        JButton btn = new JButton("<html><center><span style='font-size:20px'>" + icon + "</span><br><b>" + nom + "</b><br><span style='font-size:10px'>" + desc + "</span></center></html>");
        btn.putClientProperty("tipus", tipus);
        btn.addActionListener(e -> {
            tipusPersonatgeSeleccionat = tipus;
            actualitzarSeleccioPersonatge();
        });
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        return btn;
    }

    private JButton crearBotoDificultat(String nom, String desc, String dif) {
        JButton btn = new BotoOrnamental("<html><center>" + nom + "<br><span style='font-size:11px'>" + desc + "</span></center></html>",
                new Color(82, 17, 25), new Color(220, 174, 72), 18);
        btn.putClientProperty("dif", dif);
        btn.addActionListener(e -> {
            dificultatSeleccionada = dif;
            actualitzarSeleccioDificultat();
        });
        return btn;
    }

    private void actualitzarSeleccioPersonatge() {
        String[] tipus = {Constants.TIPUS_MAG, Constants.TIPUS_GUERRER, Constants.TIPUS_SACERDOT};
        for (int i = 0; i < btnsPersonatge.length; i++) {
            boolean seleccionat = tipusPersonatgeSeleccionat.equals(tipus[i]);
            btnsPersonatge[i].setBackground(seleccionat ? new Color(116, 82, 25) : new Color(28, 23, 20));
            btnsPersonatge[i].setForeground(seleccionat ? Color.WHITE : new Color(190, 160, 96));
            btnsPersonatge[i].setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(seleccionat ? new Color(250, 213, 104) : new Color(94, 75, 43), seleccionat ? 2 : 1),
                    new EmptyBorder(8, 4, 8, 4)));
            btnsPersonatge[i].setFont(new Font("Serif", Font.BOLD, 12));
        }
    }

    private void actualitzarSeleccioDificultat() {
        String[] difs = {Constants.DIFICULTAT_FACIL, Constants.DIFICULTAT_INTERMEDIA, Constants.DIFICULTAT_DIFICIL};
        for (int i = 0; i < btnsDificultat.length; i++) {
            boolean seleccionat = dificultatSeleccionada.equals(difs[i]);
            btnsDificultat[i].putClientProperty("seleccionat", seleccionat);
            btnsDificultat[i].repaint();
        }
    }

    private void iniciarPartida() {
        String nom = txtNom.getText().trim();
        if (nom.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Introdueix el teu nom d'aventurer!",
                    "Camp buit", JOptionPane.WARNING_MESSAGE);
            return;
        }
        GestorBD bd = GestorBD.getInstance();
        int[] existent = bd.cercar_usuari(nom);
        int idUsuari;
        if (existent != null) {
            idUsuari = existent[0];
        } else if (bd.isBdDisponible()) {
            int opcio = JOptionPane.showConfirmDialog(this,
                    "Usuari no trobat. Vols crear un nou aventurer amb aquest nom?",
                    "Nou usuari",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);
            if (opcio != JOptionPane.YES_OPTION) {
                txtNom.requestFocusInWindow();
                return;
            }
            idUsuari = bd.crear_usuari(nom, tipusPersonatgeSeleccionat);
        } else {
            idUsuari = 0;
        }
        if (idUsuari == -1) idUsuari = 0;

        motorJoc.iniciar_partida(nom, dificultatSeleccionada, tipusPersonatgeSeleccionat, idUsuari);

        Personatge personatge = motorJoc.getPersonatge();
        BarraEstat barraEstat = new BarraEstat(personatge, motorJoc.getNombreTrampes());

        JFrame frameJoc = new JFrame("Buscamines del Regne Male\u00eft  \u2014  " + nom);
        frameJoc.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        TaulerJoc taulerJoc = new TaulerJoc(motorJoc, barraEstat, frameJoc, () -> {
            frameJoc.dispose();
            setVisible(true);
        });
        frameJoc.addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                int opcio = JOptionPane.showConfirmDialog(frameJoc,
                        "Vols tornar al menu principal? La partida actual es perdra.",
                        "Sortir de la partida",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);
                if (opcio == JOptionPane.YES_OPTION) {
                    motorJoc.derrota();
                } else {
                    taulerJoc.requestFocusInWindow();
                }
            }
        });

        JButton btnBandera = new JButton("\u2691");
        btnBandera.setToolTipText("Mode bandera");
        btnBandera.setFont(new Font("Serif", Font.BOLD, 18));
        btnBandera.setForeground(Constants.COLOR_DAURAT_CLAR);
        btnBandera.setBackground(new Color(50, 34, 18));
        btnBandera.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Constants.COLOR_DAURAT, 2),
                new EmptyBorder(8, 12, 8, 12)));
        btnBandera.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnBandera.setFocusPainted(false);
        btnBandera.setOpaque(true);
        btnBandera.addActionListener(e -> {
            taulerJoc.setModeBandera(!taulerJoc.isModeBandera());
            if (taulerJoc.isModeBandera()) {
                btnBandera.setBackground(Constants.COLOR_DAURAT);
                btnBandera.setForeground(new Color(20, 10, 4));
            } else {
                btnBandera.setBackground(new Color(50, 34, 18));
                btnBandera.setForeground(Constants.COLOR_DAURAT_CLAR);
            }
        });

        JPanel topBar = new JPanel(new BorderLayout(0, 0));
        topBar.setBackground(Constants.COLOR_PEDRA.darker());
        topBar.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Constants.COLOR_DAURAT));
        topBar.add(barraEstat, BorderLayout.CENTER);
        topBar.add(btnBandera, BorderLayout.EAST);

        JScrollPane scroll = new JScrollPane(taulerJoc);
        scroll.setBackground(Constants.COLOR_FONS_FOSC);
        scroll.getViewport().setBackground(Constants.COLOR_FONS_FOSC);
        scroll.setBorder(null);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

        frameJoc.setLayout(new BorderLayout());
        frameJoc.add(topBar, BorderLayout.NORTH);
        frameJoc.add(scroll, BorderLayout.CENTER);
        frameJoc.setSize(Constants.FINESTRA_AMPLADA, Constants.FINESTRA_ALCADA);
        frameJoc.setResizable(false);
        frameJoc.setLocationRelativeTo(null);

        setVisible(false);
        frameJoc.setVisible(true);
        taulerJoc.actualitzar_ui_tauler();
        SwingUtilities.invokeLater(taulerJoc::requestFocusInWindow);
    }

    private static class FonsIniciPanel extends JPanel {
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            g2.setPaint(new GradientPaint(0, 0, new Color(28, 17, 10), 0, h, new Color(9, 6, 4)));
            g2.fillRect(0, 0, w, h);
            g2.setColor(new Color(255, 255, 255, 30));
            dibuixarArcPunts(g2, w / 2, 12, 210, 6);
            dibuixarArcPunts(g2, 44, h - 16, 160, 6);
            dibuixarArcPunts(g2, w - 44, h - 20, 160, 6);
            g2.setColor(new Color(0, 0, 0, 55));
            for (int y = 0; y < h; y += 7) {
                g2.drawLine(0, y, w, y);
            }
            g2.dispose();
        }

        private void dibuixarArcPunts(Graphics2D g2, int cx, int cy, int radi, int pas) {
            for (int r = 35; r < radi; r += 10) {
                for (int a = 190; a < 350; a += pas) {
                    double rad = Math.toRadians(a);
                    int x = cx + (int) (Math.cos(rad) * r);
                    int y = cy + (int) (Math.sin(rad) * r);
                    g2.fillOval(x, y, 2, 2);
                }
            }
        }
    }

    private static class BotoOrnamental extends JButton {
        private final Color fons;
        private final Color text;
        private final int midaFont;

        BotoOrnamental(String label, Color fons, Color text, int midaFont) {
            super(label);
            this.fons = fons;
            this.text = text;
            this.midaFont = midaFont;
            setForeground(text);
            setFont(new Font("Serif", Font.BOLD, midaFont));
            setBorder(new EmptyBorder(11, 14, 11, 14));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { repaint(); }
                @Override public void mouseExited(MouseEvent e) { repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            boolean selected = Boolean.TRUE.equals(getClientProperty("seleccionat"));
            Color base = selected ? fons.brighter() : fons;
            if (getModel().isRollover()) base = base.brighter();
            g2.setPaint(new GradientPaint(0, 0, base.brighter(), 0, getHeight(), base.darker()));
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            g2.setColor(selected ? new Color(255, 225, 116) : new Color(157, 116, 42));
            g2.setStroke(new BasicStroke(selected ? 3f : 2f));
            g2.drawRoundRect(3, 3, getWidth() - 7, getHeight() - 7, 12, 12);
            g2.drawLine(18, getHeight() / 2, 56, getHeight() / 2);
            g2.drawLine(getWidth() - 56, getHeight() / 2, getWidth() - 18, getHeight() / 2);
            g2.dispose();
            setFont(new Font("Serif", Font.BOLD, midaFont));
            setForeground(selected ? Color.WHITE : text);
            super.paintComponent(g);
        }
    }
}
