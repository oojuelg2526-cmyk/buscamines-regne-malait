package vista;

import model.Personatge;
import util.Constants;

import javax.swing.*;
import java.awt.*;

public class BarraEstat extends JPanel {

    private final JLabel lblPersonatge;
    private final JLabel lblVides;
    private final JLabel lblBanderes;
    private final JLabel lblRestants;
    private final JLabel lblCronometre;
    private final JLabel lblPuntuacio;
    private final JLabel lblMultiplicador;
    private final JLabel lblModeBandera;

    public BarraEstat(Personatge personatge, int nombreTrampes) {
        setLayout(new FlowLayout(FlowLayout.CENTER, 14, 7));
        setPreferredSize(new Dimension(0, Constants.BARRA_ESTAT_ALCADA));
        setOpaque(false);

        lblPersonatge = crearLabel(personatge.getIconaPersonatge()
            + "  " + personatge.getNom()
            + "  \u2014  " + personatge.getTipusPersonatge(), 14, Constants.COLOR_DAURAT_CLAR, Font.BOLD);
        lblVides = crearLabel(construirVides(personatge.getVides()), 16, new Color(230, 70, 70), Font.PLAIN);
        lblBanderes = crearLabel("\u2691  " + nombreTrampes, 14, new Color(180, 210, 255), Font.BOLD);
        lblRestants = crearLabel("\u25A6  --", 14, new Color(180, 185, 170), Font.BOLD);
        lblCronometre = crearLabel("\u23F1  00:00", 14, new Color(200, 230, 200), Font.BOLD);
        lblPuntuacio = crearLabel("\u2605  0 pts", 14, Constants.COLOR_DAURAT_CLAR, Font.BOLD);
        lblMultiplicador = crearLabel("", 16, new Color(255, 220, 80), Font.BOLD);
        lblModeBandera = crearLabel("", 13, new Color(255, 90, 80), Font.BOLD);
        JLabel lblTecles = crearLabel("\u2328  \u2191\u2193\u2190\u2192 moure | ENTER revelar | F bandera", 12,
                new Color(150, 125, 75), Font.PLAIN);

        add(lblPersonatge);
        add(crearSep());
        add(lblVides);
        add(crearSep());
        add(lblBanderes);
        add(crearSep());
        add(lblRestants);
        add(crearSep());
        add(lblCronometre);
        add(crearSep());
        add(lblPuntuacio);
        add(lblMultiplicador);
        add(lblModeBandera);
        add(crearSep());
        add(lblTecles);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setPaint(new GradientPaint(0, 0, new Color(42, 28, 14),
                getWidth(), 0, new Color(18, 10, 4)));
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.setColor(new Color(100, 75, 45));
        g2.drawLine(0, getHeight() - 1, getWidth(), getHeight() - 1);
        g2.dispose();
    }

    private JLabel crearLabel(String text, int mida, Color color, int estil) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Serif", estil, mida));
        lbl.setForeground(color);
        lbl.setOpaque(false);
        return lbl;
    }

    private JLabel crearSep() {
        JLabel s = new JLabel("\u2502");
        s.setFont(new Font("Serif", Font.PLAIN, 18));
        s.setForeground(new Color(105, 80, 45));
        return s;
    }

    private String construirVides(int vides) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < vides; i++) sb.append("\u2665");
        return sb.toString();
    }

    public void actualitzarCronometre(int tempsSecs) {
        int min = tempsSecs / 60;
        int sec = tempsSecs % 60;
        lblCronometre.setText(String.format("\u23F1  %02d:%02d", min, sec));
    }

    public void actualitzarBanderes(int restants) {
        lblBanderes.setText("\u2691  " + restants);
        lblBanderes.setForeground(restants < 0 ? new Color(255, 80, 80) : new Color(180, 210, 255));
    }

    public void actualitzarRestants(int restants) {
        lblRestants.setText("\u25A6  " + restants);
    }

    public void actualitzarPuntuacio(int punts) {
        lblPuntuacio.setText("\u2605  " + punts + " pts");
    }

    public void actualitzarMultiplicador(int multiplicador) {
        lblMultiplicador.setText(multiplicador > 1 ? "\u00D7" + multiplicador : "");
    }

    public void actualitzarModeBandera(boolean actiu) {
        lblModeBandera.setText(actiu ? "MODE BANDERA ACTIU" : "");
    }
}
