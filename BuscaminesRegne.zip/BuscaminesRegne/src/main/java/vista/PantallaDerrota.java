package vista;

import model.Personatge;
import util.Constants;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class PantallaDerrota extends JDialog {

    public PantallaDerrota(JFrame parent, int tempsSecs, Personatge personatge) {
        super(parent, "Derrota...", true);
        setSize(390, 340);
        setLocationRelativeTo(parent);
        setResizable(false);

        JPanel fons = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setPaint(new GradientPaint(0, 0, new Color(30, 5, 5), 0, getHeight(), new Color(10, 0, 0)));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        fons.setBorder(BorderFactory.createLineBorder(new Color(180, 30, 30), 3));

        JLabel lblTitol = new JLabel("\u2620  HAS CAIGUT EN UNA TRAMPA!", SwingConstants.CENTER);
        lblTitol.setFont(new Font("Serif", Font.BOLD, 21));
        lblTitol.setForeground(new Color(255, 80, 80));
        lblTitol.setBorder(new EmptyBorder(30, 20, 14, 20));
        fons.add(lblTitol, BorderLayout.NORTH);

        JPanel info = new JPanel(new GridLayout(2, 1, 0, 10));
        info.setOpaque(false);
        info.setBorder(new EmptyBorder(10, 34, 10, 34));

        JLabel lblPersonatge = crearInfo(personatge.getNom() + " — " + personatge.getTipusPersonatge(), 15, Constants.COLOR_DAURAT_CLAR);
        JLabel lblTemps = crearInfo("Has sobreviscut: " + String.format("%02d:%02d", tempsSecs/60, tempsSecs%60), 14, Constants.COLOR_PEDRA_CLARA);
        info.add(lblPersonatge);
        info.add(lblTemps);
        fons.add(info, BorderLayout.CENTER);

        JButton btnTancar = new JButton("Tornar al Menú");
        btnTancar.setBackground(new Color(80, 15, 15));
        btnTancar.setForeground(new Color(255, 150, 150));
        btnTancar.setFont(new Font("Serif", Font.BOLD, 16));
        btnTancar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 40, 40), 2),
            new EmptyBorder(12, 24, 12, 24)));
        btnTancar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnTancar.setFocusPainted(false);
        btnTancar.setOpaque(true);
        btnTancar.addActionListener(e -> dispose());

        JPanel pBoto = new JPanel();
        pBoto.setOpaque(false);
        pBoto.setBorder(new EmptyBorder(8, 0, 24, 0));
        pBoto.add(btnTancar);
        fons.add(pBoto, BorderLayout.SOUTH);
        setContentPane(fons);
    }

    private JLabel crearInfo(String text, int mida, Color color) {
        JLabel lbl = new JLabel(text, SwingConstants.CENTER);
        lbl.setFont(new Font("Serif", Font.BOLD, mida));
        lbl.setForeground(color);
        return lbl;
    }
}
