import controlador.GestorBD;
import util.Constants;
import vista.PantallaInici;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) {}

        configurarUIManager();

        SwingUtilities.invokeLater(() -> {
            GestorBD bd = GestorBD.getInstance();
            if (!bd.isBdDisponible()) {
                JOptionPane.showMessageDialog(null,
                    "No s'ha pogut connectar a MySQL.\n"
                    + "El joc s'executarà en MODE OFFLINE.\n"
                    + "(Les partides no es guardaran al rànquing)",
                    "Mode Offline – Buscamines del Regne Maleit",
                    JOptionPane.WARNING_MESSAGE);
            }
            PantallaInici pantalla = new PantallaInici();
            pantalla.setVisible(true);
        });
    }

    private static void configurarUIManager() {
        Font fontBase   = new Font("Serif", Font.PLAIN, 14);
        Font fontBoto   = new Font("Serif", Font.BOLD, 14);
        Font fontTitol  = new Font("Serif", Font.BOLD, 16);

        UIManager.put("Panel.background",               Constants.COLOR_FONS_FOSC);
        UIManager.put("OptionPane.background",          Constants.COLOR_FONS_FOSC);
        UIManager.put("OptionPane.messageForeground",   Constants.COLOR_DAURAT_CLAR);
        UIManager.put("Button.background",              Constants.COLOR_PEDRA);
        UIManager.put("Button.foreground",              Constants.COLOR_DAURAT);
        UIManager.put("Button.font",                    fontBoto);
        UIManager.put("Label.foreground",               Constants.COLOR_DAURAT_CLAR);
        UIManager.put("Label.font",                     fontBase);
        UIManager.put("TextField.background",           new Color(35, 22, 14));
        UIManager.put("TextField.foreground",           Constants.COLOR_DAURAT_CLAR);
        UIManager.put("TextField.caretForeground",      Constants.COLOR_DAURAT_CLAR);
        UIManager.put("TextField.font",                 new Font("Serif", Font.PLAIN, 15));
        UIManager.put("TabbedPane.background",          Constants.COLOR_PEDRA);
        UIManager.put("TabbedPane.foreground",          Constants.COLOR_DAURAT_CLAR);
        UIManager.put("TabbedPane.selected",            Constants.COLOR_PEDRA.brighter());
        UIManager.put("TabbedPane.font",                fontTitol);
        UIManager.put("ScrollPane.background",          Constants.COLOR_FONS_FOSC);
        UIManager.put("Viewport.background",            Constants.COLOR_FONS_FOSC);
        UIManager.put("ScrollBar.background",           Constants.COLOR_PEDRA);
        UIManager.put("ScrollBar.thumb",                Constants.COLOR_DAURAT.darker());
        UIManager.put("Table.background",               Constants.COLOR_PEDRA);
        UIManager.put("Table.foreground",               Constants.COLOR_DAURAT_CLAR);
        UIManager.put("Table.font",                     new Font("Serif", Font.PLAIN, 13));
        UIManager.put("TableHeader.background",         Constants.COLOR_PEDRA.darker());
        UIManager.put("TableHeader.foreground",         Constants.COLOR_DAURAT_CLAR);
        UIManager.put("TableHeader.font",               fontBoto);
    }
}
