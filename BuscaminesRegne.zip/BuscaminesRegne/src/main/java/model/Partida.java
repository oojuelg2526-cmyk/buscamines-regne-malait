package model;

import java.time.LocalDateTime;

public class Partida {
    private int idUsuari;
    private int idNivell;
    private String tipusPersonatge;
    private int puntuacioObtinguda;
    private int tempsSecs;
    private int ampliacions;
    private String resultat;
    private LocalDateTime dataPartida;

    public Partida(int idUsuari, int idNivell, String tipusPersonatge,
                   int puntuacio, int tempsSecs, int ampliacions, String resultat) {
        this.idUsuari = idUsuari;
        this.idNivell = idNivell;
        this.tipusPersonatge = tipusPersonatge;
        this.puntuacioObtinguda = puntuacio;
        this.tempsSecs = tempsSecs;
        this.ampliacions = ampliacions;
        this.resultat = resultat;
        this.dataPartida = LocalDateTime.now();
    }

    public int getIdUsuari()             { return idUsuari; }
    public int getIdNivell()             { return idNivell; }
    public String getTipusPersonatge()   { return tipusPersonatge; }
    public int getPuntuacioObtinguda()   { return puntuacioObtinguda; }
    public int getTempsSecs()            { return tempsSecs; }
    public int getAmpliacions()          { return ampliacions; }
    public String getResultat()          { return resultat; }
    public LocalDateTime getDataPartida(){ return dataPartida; }
}
