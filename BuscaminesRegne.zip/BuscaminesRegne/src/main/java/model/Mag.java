package model;

public class Mag extends Personatge {
    public Mag(String nom) {
        super(nom);
        this.vides = 3;
        this.velocitat = 7;
        this.tipusPersonatge = "Mag";
    }
    @Override public double getBonusRapidesa() { return 1.5; }
    @Override public String getIconaPersonatge() { return "\uD83E\uDDD9"; }
}
