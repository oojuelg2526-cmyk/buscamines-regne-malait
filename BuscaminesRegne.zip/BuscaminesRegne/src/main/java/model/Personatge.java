package model;

import java.util.ArrayList;
import java.util.List;

public abstract class Personatge {
    protected String nom;
    protected int vides;
    protected int velocitat;
    protected String tipusPersonatge;
    protected List<String> objectes;

    public Personatge(String nom) {
        this.nom = nom;
        this.objectes = new ArrayList<>();
    }

    public abstract double getBonusRapidesa();
    public abstract String getIconaPersonatge();

    public String getNom()             { return nom; }
    public void setNom(String nom)     { this.nom = nom; }
    public int getVides()              { return vides; }
    public void setVides(int v)        { this.vides = v; }
    public int getVelocitat()          { return velocitat; }
    public String getTipusPersonatge() { return tipusPersonatge; }
    public List<String> getObjectes()  { return objectes; }
}
