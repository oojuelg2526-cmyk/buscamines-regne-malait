package model;

public class Sacerdot extends Personatge {
    public Sacerdot(String nom) {
        super(nom);
        this.vides = 4;
        this.velocitat = 5;
        this.tipusPersonatge = "Sacerdot";
    }
    @Override public double getBonusRapidesa() { return 1.0; }
    @Override public String getIconaPersonatge() { return "\u271D"; }
}
