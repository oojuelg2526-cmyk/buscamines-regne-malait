package model;

public class Guerrer extends Personatge {
    public Guerrer(String nom) {
        super(nom);
        this.vides = 5;
        this.velocitat = 3;
        this.tipusPersonatge = "Guerrer";
    }
    @Override public double getBonusRapidesa() { return 0.8; }
    @Override public String getIconaPersonatge() { return "\u2694"; }
}
