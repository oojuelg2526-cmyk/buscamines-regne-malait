package model;

public class Casella {
    private boolean esTrampa;
    private boolean revelada;
    private boolean marcadaBandera;
    private boolean zonaNova;
    private int nombreTrampaAdjacents;

    public Casella() {
        this.esTrampa = false;
        this.revelada = false;
        this.marcadaBandera = false;
        this.zonaNova = false;
        this.nombreTrampaAdjacents = 0;
    }

    public boolean isEsTrampa()           { return esTrampa; }
    public void setEsTrampa(boolean v)    { this.esTrampa = v; }
    public boolean isRevelada()           { return revelada; }
    public void setRevelada(boolean v)    { this.revelada = v; }
    public boolean isMarcadaBandera()     { return marcadaBandera; }
    public void setMarcadaBandera(boolean v) { this.marcadaBandera = v; }
    public boolean isZonaNova()           { return zonaNova; }
    public void setZonaNova(boolean v)    { this.zonaNova = v; }
    public int getNombreTrampaAdjacents() { return nombreTrampaAdjacents; }
    public void setNombreTrampaAdjacents(int v) { this.nombreTrampaAdjacents = v; }
}
