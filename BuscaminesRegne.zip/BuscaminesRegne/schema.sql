-- ================================================================
-- schema.sql – Script de creació de la BD per al
-- Buscamines del Regne Maleit
--
-- Executa aquest script a MySQL abans de llançar el joc:
--   mysql -u root -p < schema.sql
-- ================================================================

CREATE DATABASE IF NOT EXISTS buscamines_regne
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE buscamines_regne;

CREATE TABLE IF NOT EXISTS usuaris (
  id_usuari       INT AUTO_INCREMENT PRIMARY KEY,
  nom_jugador     VARCHAR(50) NOT NULL UNIQUE,
  tipus_personatge VARCHAR(20),
  punts_totals    INT NOT NULL DEFAULT 0,
  data_creacio    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS nivells (
  id_nivell       INT AUTO_INCREMENT PRIMARY KEY,
  nom_nivell      VARCHAR(20) NOT NULL,
  files           INT NOT NULL,
  columnes        INT NOT NULL,
  nombre_trampes  INT NOT NULL,
  punts_base      INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO nivells (id_nivell, nom_nivell, files, columnes, nombre_trampes, punts_base)
VALUES
  (1, 'Facil',      9,  9,  10, 100),
  (2, 'Intermedia', 16, 16, 40, 200),
  (3, 'Dificil',    24, 16, 75, 350);

UPDATE nivells SET files = 9, columnes = 9, nombre_trampes = 10, punts_base = 100 WHERE id_nivell = 1;
UPDATE nivells SET files = 16, columnes = 16, nombre_trampes = 40, punts_base = 200 WHERE id_nivell = 2;
UPDATE nivells SET files = 24, columnes = 16, nombre_trampes = 75, punts_base = 350 WHERE id_nivell = 3;

CREATE TABLE IF NOT EXISTS partides (
  id_partida          INT AUTO_INCREMENT PRIMARY KEY,
  id_usuari           INT NOT NULL,
  id_nivell           INT NOT NULL,
  tipus_personatge    VARCHAR(20),
  puntuacio_obtinguda INT NOT NULL DEFAULT 0,
  temps_segons        INT,
  ampliacions         INT NOT NULL DEFAULT 0,
  resultat            VARCHAR(20),
  data_partida        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_usuari) REFERENCES usuaris(id_usuari) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (id_nivell) REFERENCES nivells(id_nivell) ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX idx_resultat  (resultat),
  INDEX idx_usuari    (id_usuari),
  INDEX idx_puntuacio (puntuacio_obtinguda DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
